#!/usr/bin/env python
# coding: utf-8

# In[2]:


get_ipython().run_line_magic('matplotlib', 'tk')

import numpy as np 
import pandas as pd 
import matplotlib as mpl 
import matplotlib.pyplot as plt 
# 한글폰트 사용
# plt.rc('font', family='NanumBarunGothic')
# mpl.rcParams['axes.unicode_minus'] = False

plt.rcParams['font.family'] ='Malgun Gothic'
plt.rcParams['axes.unicode_minus'] =False

def population(pop):    
    #지역별 인구수와 인구 소멸율 
    plt.figure(figsize=(12,8))
    plt.scatter(pop['2020년_계_예측 총인구수'],pop['소멸비율'],s=(pop['소멸비율']*10)**2)
    plt.title('2020년도 인구수 대비 소멸비율',fontsize=20)

    fp1 = np.polyfit(pop['2020년_계_예측 총인구수'],pop['소멸비율'], 1)   #np.polyfit:직선을 구성하기 위한 계수 계산
    fx = np.linspace(0,832227,2)
    fy = np.poly1d(fp1)              #np.poly1d:polyfit으로 찾은 계수로 파이썬에서 사용할 함수를 만들어줌
    plt.plot(fx, fy(fx), ls='dashed', lw=3, color='r')
    
    
def woman_2039(pop):
    #지역별 청년여성 인구와 인구 소멸율 
    pop['20-39세여자비율']=pop['여_20-39세']/pop['계_20-39세'] # 20-39세여자비율

    plt.figure(figsize=(12,8))
    plt.scatter(pop['20-39세여자비율'],pop['소멸비율'],s=(pop['소멸비율']*10)**2)
    plt.xlabel('2020년도 20-39세여자비율')
    plt.ylabel('소멸비율')
    plt.title('20-39세여자비율 대비 소멸비율')

    fp1 = np.polyfit(pop['20-39세여자비율'],pop['소멸비율'], 1)
    fx = np.linspace(0.3,0.6,2)
    fy = np.poly1d(fp1)
    plt.plot(fx, fy(fx), ls='dashed', lw=3, color='r')
    

def youngman_2039(pop):
    #지역별 청년 인구와 인구 소멸율
    pop['20-39세청년비율']=pop['계_20-39세']/pop['2020년_계_예측 총인구수']
    plt.figure(figsize=(12,8))
    plt.scatter(pop['20-39세청년비율'],pop['소멸비율'],s=(pop['소멸비율']*10)**2)
    plt.xlabel('2020년도 20-39세청년비율')
    plt.ylabel('소멸비율')
    plt.title('20-39세청년비율 대비 소멸비율')

    fp1 = np.polyfit(pop['20-39세청년비율'],pop['소멸비율'], 1)
    fx = np.linspace(0,0.4,2)
    fy = np.poly1d(fp1)
    plt.plot(fx, fy(fx), ls='dashed', lw=3, color='r')
    
    
def more_65(pop):
    #지역별 노년 인구와 인구 소멸율 
    pop['65세이상비율']=pop['계_65세이상']/pop['2020년_계_예측 총인구수']
    plt.figure(figsize=(12,8))
    plt.scatter(pop['65세이상비율'],pop['소멸비율'],s=(pop['소멸비율']*10)**2)
    plt.xlabel('2020년도 65세이상비율')
    plt.ylabel('소멸비율')
    plt.title('65세이상비율 대비 소멸비율')

    fp1 = np.polyfit(pop['65세이상비율'],pop['소멸비율'], 1)
    fx = np.linspace(0,0.4,2)
    fy = np.poly1d(fp1)
    plt.plot(fx, fy(fx), ls='dashed', lw=3, color='r')






    